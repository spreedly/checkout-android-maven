package com.spreedly.sdk.ui

import androidx.compose.foundation.layout.imePadding
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import com.spreedly.hostedfields.ui.FormFieldType
import com.spreedly.paymentsheet.PaymentSheet
import com.spreedly.sdk.Spreedly

@Composable
fun SpreedlyBottomSheet(
    sdk: Spreedly,
    modifier: Modifier = Modifier,
) {
    val showBottomSheet by sdk.showBottomSheet
    val paymentState by sdk.paymentState
    val config by sdk.config
    val coroutineScope = rememberCoroutineScope()

    if (showBottomSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

        ModalBottomSheet(
            onDismissRequest = {
                sdk.notifyPaymentCancelled()
                sdk.hideBottomSheet()
            },
            sheetState = sheetState,
            modifier = modifier,
        ) {
            PaymentSheet(
                state = paymentState,
                callbacks = sdk.callbacks,
                config = config,
                modifier = Modifier.imePadding(),
                button = {
                    CheckoutButton(
                        formFields =
                        listOf(
                            FormFieldType.CARD(true),
                            FormFieldType.EXPIRY_DATE(true),
                            FormFieldType.CVV(true),
                            FormFieldType.NAME(true),
                            FormFieldType.CITY(false),
                            FormFieldType.STATE(false),
                            FormFieldType.ADDRESS_LINE_1(false),
                            FormFieldType.ADDRESS_LINE_2(false),
                            FormFieldType.ZIP(false),
                        ),
                        sdk = sdk,
                    )
                },
            )
        }
    }
}
