package com.spreedly.sdk.paymentmanager;

import com.spreedly.sdk.api.SpreedlyApiService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SpreedlyPaymentManager_Factory implements Factory<SpreedlyPaymentManager> {
  private final Provider<SpreedlyApiService> apiServiceProvider;

  public SpreedlyPaymentManager_Factory(Provider<SpreedlyApiService> apiServiceProvider) {
    this.apiServiceProvider = apiServiceProvider;
  }

  @Override
  public SpreedlyPaymentManager get() {
    return newInstance(apiServiceProvider.get());
  }

  public static SpreedlyPaymentManager_Factory create(
      Provider<SpreedlyApiService> apiServiceProvider) {
    return new SpreedlyPaymentManager_Factory(apiServiceProvider);
  }

  public static SpreedlyPaymentManager newInstance(SpreedlyApiService apiService) {
    return new SpreedlyPaymentManager(apiService);
  }
}
