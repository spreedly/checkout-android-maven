package com.spreedly.sdk

import androidx.compose.runtime.State
import com.spreedly.hostedfields.ui.FormFieldType
import com.spreedly.network.ApiClientBuilder
import com.spreedly.network.AppNetworkError
import com.spreedly.network.RequestHandler
import com.spreedly.paymentsheet.PaymentSheetCallbacks
import com.spreedly.paymentsheet.PaymentSheetConfig
import com.spreedly.paymentsheet.PaymentSheetState
import com.spreedly.result.Result
import com.spreedly.sdk.api.SpreedlyApiService
import com.spreedly.sdk.auth.AuthParamsService
import com.spreedly.sdk.models.PaymentMethodResponse
import com.spreedly.sdk.paymentmanager.SpreedlyPaymentManager
import com.spreedly.sdk.ui.PaymentResult
import com.spreedly.sdk.ui.SpreedlyUIController
import io.ktor.http.URLProtocol
import kotlinx.coroutines.flow.SharedFlow
import javax.inject.Inject

class Spreedly
@Inject
constructor(apiService: SpreedlyApiService) {
    companion object {
        /**
         * Create a Spreedly instance with a default RequestHandler
         */
        fun create(): Spreedly {
            val httpClient =
                ApiClientBuilder()
                    .protocol(URLProtocol.HTTPS)
                    .host("core.spreedly.com")
                    .build()
            val requestHandler = RequestHandler(httpClient)
            val apiService = SpreedlyApiService(requestHandler)
            return Spreedly(apiService)
        }
    }

    private val paymentManager = SpreedlyPaymentManager(apiService)

    private val uiController = SpreedlyUIController()

    private val authParamsService = AuthParamsService()

    val paymentResultFlow: SharedFlow<PaymentResult>
        get() = paymentManager.paymentResultFlow

    fun init(options: SpreedlySDKInitOptions) {
        paymentManager.initialize(options)
        uiController.setConfig(options.config)
    }

    /**
     * Initialize the SDK by fetching authentication parameters from the remote API
     */
    suspend fun init(
        environmentKey: String,
        config: PaymentSheetConfig = PaymentSheetConfig.Default,
    ): Result<Unit, AppNetworkError> =
        when (val authResult = authParamsService.getAuthParams()) {
            is Result.Success -> {
                val authParams = authResult.data
                val options =
                    SpreedlySDKInitOptions(
                        token = "",
                        nonce = authParams.nonce,
                        signature = authParams.signature,
                        certificateToken = authParams.certificateToken,
                        timestamp = authParams.timestamp.toString(),
                        config = config,
                        environmentKey = environmentKey,
                    )
                init(options)
                Result.Success(Unit)
            }

            is Result.Error -> {
                Result.Error(authResult.error)
            }
        }

    fun expressCheckout(config: PaymentSheetConfig = PaymentSheetConfig.Default) {
        uiController.setConfig(config)
        uiController.showBottomSheet()
    }

    fun hideBottomSheet() {
        uiController.hideBottomSheet()
    }

    fun notifyPaymentCancelled() {
        paymentManager.notifyPaymentCancelled()
    }

    fun notifyPaymentSuccess(token: String) {
        paymentManager.notifyPaymentSuccess(token = token)
    }

    fun notifyPaymentFailed(error: Throwable) {
        paymentManager.notifyPaymentFailed(error)
    }

    val callbacks: PaymentSheetCallbacks get() = uiController.callbacks

    val paymentState: State<PaymentSheetState> get() = uiController.paymentState

    fun shouldShowError(type: FormFieldType): Boolean = uiController.showDisplayError(type)

    val showBottomSheet: State<Boolean> get() = uiController.showBottomSheet

    val config: State<PaymentSheetConfig> get() = uiController.config

    suspend fun createPaymentMethod(
        metadata: Map<String, Any> = emptyMap(),
    ): Result<PaymentMethodResponse, AppNetworkError> =
        paymentManager.createPaymentMethod(uiController.paymentState.value, metadata)

    fun resetPaymentState() {
        uiController.resetPaymentState()
    }
}
