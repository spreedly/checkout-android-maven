package com.spreedly.sdk.auth

import com.spreedly.network.ApiClientBuilder
import com.spreedly.network.AppNetworkError
import com.spreedly.network.RequestHandler
import com.spreedly.result.Result
import com.spreedly.sdk.models.AuthParamsResponse
import io.ktor.http.URLProtocol

class AuthParamsService {
    private val httpClient =
        ApiClientBuilder()
            .protocol(URLProtocol.HTTPS)
            .host("checkout-web-sample-app-049a3c617015.herokuapp.com")
            .build()

    private val requestHandler = RequestHandler(httpClient)

    suspend fun getAuthParams(): Result<AuthParamsResponse, AppNetworkError> =
        requestHandler.get<AuthParamsResponse>(
            url = "/api/auth/get-auth-params",
        )
}
