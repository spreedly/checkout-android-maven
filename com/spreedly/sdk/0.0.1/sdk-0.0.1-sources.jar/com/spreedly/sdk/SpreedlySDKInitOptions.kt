package com.spreedly.sdk

import com.spreedly.paymentsheet.PaymentSheetConfig

data class SpreedlySDKInitOptions(
    val token: String,
    val nonce: String,
    val signature: String,
    val certificateToken: String,
    val timestamp: String,
    val environmentKey: String,
    val config: PaymentSheetConfig = PaymentSheetConfig.Default,
)
