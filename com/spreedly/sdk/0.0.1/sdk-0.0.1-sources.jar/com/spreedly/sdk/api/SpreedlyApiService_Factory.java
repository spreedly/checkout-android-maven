package com.spreedly.sdk.api;

import com.spreedly.network.RequestHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SpreedlyApiService_Factory implements Factory<SpreedlyApiService> {
  private final Provider<RequestHandler> requestHandlerProvider;

  public SpreedlyApiService_Factory(Provider<RequestHandler> requestHandlerProvider) {
    this.requestHandlerProvider = requestHandlerProvider;
  }

  @Override
  public SpreedlyApiService get() {
    return newInstance(requestHandlerProvider.get());
  }

  public static SpreedlyApiService_Factory create(Provider<RequestHandler> requestHandlerProvider) {
    return new SpreedlyApiService_Factory(requestHandlerProvider);
  }

  public static SpreedlyApiService newInstance(RequestHandler requestHandler) {
    return new SpreedlyApiService(requestHandler);
  }
}
