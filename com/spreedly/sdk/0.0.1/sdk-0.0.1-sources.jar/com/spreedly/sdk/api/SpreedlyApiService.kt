package com.spreedly.sdk.api

import com.spreedly.network.AppNetworkError
import com.spreedly.network.RequestHandler
import com.spreedly.result.Result
import com.spreedly.sdk.models.PaymentMethodRequest
import com.spreedly.sdk.models.PaymentMethodResponse
import javax.inject.Inject

/**
 * Service class for making API calls to the Spreedly API
 */
class SpreedlyApiService
@Inject
constructor(private val requestHandler: RequestHandler) {
    /**
     * Create a payment method
     *
     * @param request The payment method request
     * @return Result containing the payment method response or an error
     */
    suspend fun createPaymentMethod(request: PaymentMethodRequest): Result<PaymentMethodResponse, AppNetworkError> =
        requestHandler.post(
            url = "v1/payment_methods.json",
            body = request,
            queryParams = mapOf("environment_key" to request.environmentKey),
        )
}
