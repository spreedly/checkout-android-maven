package com.spreedly.sdk;

import com.spreedly.sdk.api.SpreedlyApiService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class Spreedly_Factory implements Factory<Spreedly> {
  private final Provider<SpreedlyApiService> apiServiceProvider;

  public Spreedly_Factory(Provider<SpreedlyApiService> apiServiceProvider) {
    this.apiServiceProvider = apiServiceProvider;
  }

  @Override
  public Spreedly get() {
    return newInstance(apiServiceProvider.get());
  }

  public static Spreedly_Factory create(Provider<SpreedlyApiService> apiServiceProvider) {
    return new Spreedly_Factory(apiServiceProvider);
  }

  public static Spreedly newInstance(SpreedlyApiService apiService) {
    return new Spreedly(apiService);
  }
}
