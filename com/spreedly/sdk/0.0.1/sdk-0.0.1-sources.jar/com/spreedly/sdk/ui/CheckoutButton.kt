package com.spreedly.sdk.ui

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.spreedly.hostedfields.ui.FormFieldType
import com.spreedly.sdk.Spreedly
import com.spreedly.ui.theme.AppTheme
import kotlinx.coroutines.launch

@SuppressLint("ComposeUnstableCollections")
@Composable
fun CheckoutButton(
    sdk: Spreedly,
    formFields: List<FormFieldType>,
    modifier: Modifier = Modifier,
    text: String = "Checkout",
    metadata: Map<String, Any> = emptyMap(),
    isInitializing: Boolean = false,
) {
    var isProcessing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val isButtonDisabled = isInitializing || isProcessing

    Button(
        colors =
        ButtonDefaults.buttonColors(
            containerColor = Color(0xFF6366F1),
            disabledContainerColor = Color(0xFF9CA3AF),
        ),
        enabled = !isButtonDisabled,
        onClick = {
            coroutineScope.launch {
                /**
                 * Validate all fields and show errors for each invalid field
                 */
                val validationResults =
                    formFields.map { field ->
                        field to (if (field.required) !sdk.shouldShowError(field) else true)
                    }
                val allRequiredFieldsValid = validationResults.all { (_, isValid) -> isValid }

                if (allRequiredFieldsValid) {
                    isProcessing = true

                    // Read all values from SdkInternalState
                    val result = sdk.createPaymentMethod(metadata)
                    when (result) {
                        is com.spreedly.result.Result.Error -> {
                            sdk.notifyPaymentFailed(Exception(result.error.toString()))
                        }

                        is com.spreedly.result.Result.Success -> {
                            val data = result.data
                            sdk.notifyPaymentSuccess(data.transaction.token)
                            sdk.resetPaymentState()
                        }
                    }

                    isProcessing = false
                } else {
                    sdk.notifyPaymentFailed(
                        Exception("All required fields are not valid"),
                    )
                }
            }
        },
        modifier = modifier.fillMaxWidth(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (isButtonDisabled) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(13.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text =
                when {
                    isInitializing -> "Initializing..."
                    isProcessing -> "Processing..."
                    else -> text
                },
                style = AppTheme.typography.button,
                color = Color.White,
            )
        }
    }
}
