package com.spreedly.sdk.paymentmanager

import com.spreedly.hostedfields.encryption.SpreedlyEncryption
import com.spreedly.hostedfields.encryption.SpreedlyEncryption.decryptAES
import com.spreedly.network.AppNetworkError
import com.spreedly.paymentsheet.PaymentSheetState
import com.spreedly.result.Result
import com.spreedly.sdk.SpreedlySDKInitOptions
import com.spreedly.sdk.api.SpreedlyApiService
import com.spreedly.sdk.models.CreditCard
import com.spreedly.sdk.models.Metadata
import com.spreedly.sdk.models.PaymentMethod
import com.spreedly.sdk.models.PaymentMethodRequest
import com.spreedly.sdk.models.PaymentMethodResponse
import com.spreedly.sdk.ui.PaymentResult
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject

/**
 * Manager class for handling payment-related operations
 */
class SpreedlyPaymentManager
@Inject
constructor(private val apiService: SpreedlyApiService) {
    private val _paymentResultFlow =
        MutableSharedFlow<PaymentResult>(extraBufferCapacity = 1)
    val paymentResultFlow: SharedFlow<PaymentResult> = _paymentResultFlow.asSharedFlow()

    private lateinit var spreedlySDKInitOptions: SpreedlySDKInitOptions

    /**
     * Initialize the payment manager
     */
    fun initialize(options: SpreedlySDKInitOptions) {
        spreedlySDKInitOptions = options
    }

    fun notifyPaymentCancelled() {
        _paymentResultFlow.tryEmit(PaymentResult.Canceled)
    }

    fun notifyPaymentSuccess(token: String) {
        _paymentResultFlow.tryEmit(PaymentResult.Completed(token = token))
    }

    fun notifyPaymentFailed(error: Throwable) {
        _paymentResultFlow.tryEmit(PaymentResult.Failed(error))
    }

    /**
     * Create a payment method
     *
     * @param state The payment sheet state containing the card details
     * @param metadata Custom metadata map to include with the payment method
     * @return Result containing the payment method response or an error
     */
    suspend fun createPaymentMethod(
        state: PaymentSheetState,
        metadata: Map<String, Any> = emptyMap(),
    ): Result<PaymentMethodResponse, AppNetworkError> {
        fun getDisplayValue(value: String) = decryptAES(value, SpreedlyEncryption.KEY)

        // Get month and year from separate fields or combined expiry date
        val monthStr = getDisplayValue(state.month.value).trim()
        val yearStr = getDisplayValue(state.year.value).trim()
        val expirationDate = getDisplayValue(state.expirationDate.value).trim()

        val (finalMonthStr, finalYearStr) =
            when {
                // Use separate month and year fields if they have values
                monthStr.isNotEmpty() && yearStr.isNotEmpty() -> {
                    monthStr to yearStr
                }
                // Fall back to combined expiry date field (format: MMYY or MM/YY)
                expirationDate.isNotEmpty() -> {
                    val cleanDate = expirationDate.replace("/", "").replace("-", "").replace(" ", "")
                    if (cleanDate.length >= 4) {
                        val month = cleanDate.substring(0, 2)
                        val year = cleanDate.substring(2, 4)
                        val fullYear = "20$year" // Convert YY to YYYY
                        month to fullYear
                    } else {
                        "" to ""
                    }
                }
                else -> "" to ""
            }

        val month = finalMonthStr.toIntOrNull()
        val fullYear = finalYearStr

        // Create the payment method request
        val request =
            PaymentMethodRequest(
                environmentKey = spreedlySDKInitOptions.environmentKey,
                nonce = spreedlySDKInitOptions.nonce,
                timestamp = spreedlySDKInitOptions.timestamp,
                signature = spreedlySDKInitOptions.signature,
                certificateToken = spreedlySDKInitOptions.certificateToken,
                paymentMethod =
                PaymentMethod(
                    creditCard =
                    CreditCard(
                        firstName = getDisplayValue(state.nameOnCard.value).split(" ").firstOrNull() ?: " ",
                        lastName = "last name",
                        number = getDisplayValue(state.cardNumber.value).replace(" ", ""),
                        verificationValue = getDisplayValue(state.securityCode.value),
                        month = finalMonthStr,
                        year = fullYear,
                        company = "",
                        address1 = getDisplayValue(state.addressLine1.value).ifEmpty { " " },
                        address2 = getDisplayValue(state.addressLine2.value).ifEmpty { " " },
                        city = getDisplayValue(state.city.value).ifEmpty { " " },
                        state = getDisplayValue(state.state.value).ifEmpty { " " },
                        zip = getDisplayValue(state.zipCode.value).ifEmpty { " " },
                        country = "",
                        phoneNumber = "",
                        shippingAddress1 = getDisplayValue(state.addressLine1.value).ifEmpty { " " },
                        shippingAddress2 = getDisplayValue(state.addressLine2.value).ifEmpty { " " },
                        shippingCity = getDisplayValue(state.city.value).ifEmpty { " " },
                        shippingState = getDisplayValue(state.state.value).ifEmpty { " " },
                        shippingZip = getDisplayValue(state.zipCode.value).ifEmpty { " " },
                        shippingCountry = "",
                        shippingPhoneNumber = "",
                    ),
                    email = "",
                    metadata =
                    if (metadata.isNotEmpty()) {
                        Metadata.fromMap(metadata)
                    } else {
                        Metadata.Default
                    },
                ),
            )

        // Make the API call using the API service
        return apiService.createPaymentMethod(request)
    }
}
