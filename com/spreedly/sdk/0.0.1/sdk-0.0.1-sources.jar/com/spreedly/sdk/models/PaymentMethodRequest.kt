package com.spreedly.sdk.models

import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject

/**
 * Custom serializer for Metadata that serializes as a flat JSON object
 * instead of nesting under a "data" field, as required by Spreedly API
 */
object MetadataSerializer : KSerializer<Metadata> {
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor("Metadata")

    override fun serialize(
        encoder: Encoder,
        value: Metadata,
    ) {
        val jsonObject = JsonObject(value.fields)
        encoder.encodeSerializableValue(JsonObject.serializer(), jsonObject)
    }

    override fun deserialize(decoder: Decoder): Metadata {
        val jsonObject = decoder.decodeSerializableValue(JsonObject.serializer())
        return Metadata(jsonObject.jsonObject)
    }
}

@Serializable
data class PaymentMethodRequest(
    @SerialName("environment_key")
    val environmentKey: String,
    @SerialName("nonce")
    val nonce: String,
    @SerialName("timestamp")
    val timestamp: String,
    @SerialName("signature")
    val signature: String,
    @SerialName("certificate_token")
    val certificateToken: String,
    @SerialName("payment_method")
    val paymentMethod: PaymentMethod,
)

@Serializable
data class PaymentMethod(
    @SerialName("credit_card")
    val creditCard: CreditCard,
    val email: String,
    val metadata: Metadata,
)

@Serializable
data class CreditCard(
    @SerialName("first_name")
    val firstName: String,
    @SerialName("last_name")
    val lastName: String,
    val number: String,
    @SerialName("verification_value")
    val verificationValue: String,
    val month: String,
    val year: String,
    val company: String,
    val address1: String,
    val address2: String,
    val city: String,
    val state: String,
    val zip: String,
    val country: String,
    @SerialName("phone_number")
    val phoneNumber: String,
    @SerialName("shipping_address1")
    val shippingAddress1: String,
    @SerialName("shipping_address2")
    val shippingAddress2: String,
    @SerialName("shipping_city")
    val shippingCity: String,
    @SerialName("shipping_state")
    val shippingState: String,
    @SerialName("shipping_zip")
    val shippingZip: String,
    @SerialName("shipping_country")
    val shippingCountry: String,
    @SerialName("shipping_phone_number")
    val shippingPhoneNumber: String,
)

@Serializable(with = MetadataSerializer::class)
data class Metadata(internal val fields: Map<String, JsonElement> = emptyMap()) {
    companion object {
        fun fromMap(map: Map<String, Any>): Metadata {
            val jsonElements =
                map.mapValues { (key, value) ->
                    // Validate key-value pairs according to Spreedly constraints
                    val stringValue =
                        when (value) {
                            is String -> value
                            is Number -> value.toString()
                            is Boolean -> value.toString()
                            else -> value.toString()
                        }

                    // Enforce 500 character limit per Spreedly API
                    if (stringValue.length > 500) {
                        throw IllegalArgumentException(
                            "Metadata value for key '$key' exceeds 500 character limit: ${stringValue.length} characters",
                        )
                    }

                    JsonPrimitive(stringValue)
                }
            return Metadata(jsonElements)
        }

        // Default metadata for backward compatibility
        val Default =
            fromMap(
                mapOf(
                    "key" to "string value",
                    "another_key" to "123",
                    "final_key" to "true",
                ),
            )
    }
}
