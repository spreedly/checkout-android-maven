package com.spreedly.sdk.models

import kotlinx.serialization.Serializable

@Serializable
data class AuthParamsResponse(
    val nonce: String,
    val timestamp: Long,
    val signature: String,
    val certificateToken: String,
)
