package com.spreedly.sdk.ui

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import com.spreedly.hostedfields.encryption.SpreedlyEncryption
import com.spreedly.hostedfields.encryption.SpreedlyEncryption.decryptAES
import com.spreedly.hostedfields.encryption.SpreedlyEncryption.encryptAES
import com.spreedly.hostedfields.ui.FormFieldType
import com.spreedly.paymentsheet.PaymentSheetCallbacks
import com.spreedly.paymentsheet.PaymentSheetConfig
import com.spreedly.paymentsheet.PaymentSheetState
import com.spreedly.validation.formx.CachedFormInput
import com.spreedly.validation.validators.CardNumberValidator
import com.spreedly.validation.validators.CvvValidator
import com.spreedly.validation.validators.ExpiryDateValidator
import com.spreedly.validation.validators.MonthValidator
import com.spreedly.validation.validators.RequiredValidator
import com.spreedly.validation.validators.YearValidator

class SpreedlyUIController {
    private val _showBottomSheet = mutableStateOf(false)
    val showBottomSheet: State<Boolean> = _showBottomSheet

    private val _paymentState = mutableStateOf(PaymentSheetState())
    val paymentState: State<PaymentSheetState> = _paymentState

    private val _config = mutableStateOf(PaymentSheetConfig.Companion.Default)
    val config: State<PaymentSheetConfig> = _config

    val callbacks =
        object : PaymentSheetCallbacks {
            override fun onNameOnCardChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyName = RequiredValidator(value, !isRequired)
                updatePaymentState { it.copy(nameOnCard = dirtyName) }
            }

            override fun onCardNumberChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyCardNumber = CardNumberValidator(value, !isRequired)
                updatePaymentState { it.copy(cardNumber = dirtyCardNumber) }
            }

            override fun onExpirationDateChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyExpiryDate = ExpiryDateValidator(value, !isRequired)
                updatePaymentState { it.copy(expirationDate = dirtyExpiryDate) }
            }

            override fun onSecurityCodeChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyCvv = CvvValidator(value, !isRequired)
                updatePaymentState { it.copy(securityCode = dirtyCvv) }
            }

            override fun onAddressLine1Change(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyAddress = RequiredValidator(value, !isRequired)
                updatePaymentState { it.copy(addressLine1 = dirtyAddress) }
            }

            override fun onAddressLine2Change(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyAddress = RequiredValidator(value, !isRequired)
                updatePaymentState { it.copy(addressLine2 = dirtyAddress) }
            }

            override fun onCityChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyCity = RequiredValidator(value, !isRequired)
                updatePaymentState { it.copy(city = dirtyCity) }
            }

            override fun onStateChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyState = RequiredValidator(value, !isRequired)
                updatePaymentState { it.copy(state = dirtyState) }
            }

            override fun onZipCodeChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyZipCode = RequiredValidator(value, !isRequired)
                updatePaymentState { it.copy(zipCode = dirtyZipCode) }
            }

            override fun onMonthChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyMonth = MonthValidator(value, !isRequired)
                updatePaymentState { it.copy(month = dirtyMonth) }
            }

            override fun onYearChange(
                value: String,
                isRequired: Boolean,
            ) {
                val dirtyYear = YearValidator(value, !isRequired)
                updatePaymentState { it.copy(year = dirtyYear) }
            }
        }

    fun showBottomSheet() {
        _showBottomSheet.value = true
    }

    fun hideBottomSheet() {
        _showBottomSheet.value = false
    }

    private fun updatePaymentState(update: (PaymentSheetState) -> PaymentSheetState) {
        _paymentState.value = update(_paymentState.value)
    }

    fun setConfig(config: PaymentSheetConfig) {
        _config.value = config
    }

    fun resetPaymentState() {
        _paymentState.value = PaymentSheetState()
    }

    private inline fun <T : CachedFormInput<*, *>> validateAndUpdate(
        encrypted: String,
        required: Boolean,
        constructor: (String, Boolean) -> T,
        updateState: (T) -> Unit,
    ): Boolean {
        val decrypted = decryptAES(encrypted, SpreedlyEncryption.KEY)
        val validator = constructor(decrypted, !required)

        val newEncrypted = encryptAES("$decrypted ", SpreedlyEncryption.KEY)
        val newValidator = constructor(newEncrypted, !required)
        updateState(newValidator)
        return validator.displayError != null
    }

    fun showDisplayError(type: FormFieldType): Boolean =
        when (type) {
            is FormFieldType.CARD ->
                validateAndUpdate(
                    encrypted = paymentState.value.cardNumber.value,
                    required = type.required,
                    constructor = ::CardNumberValidator,
                ) { validator -> updatePaymentState { it.copy(cardNumber = validator) } }

            is FormFieldType.EXPIRY_DATE ->
                validateAndUpdate(
                    encrypted = paymentState.value.expirationDate.value,
                    required = type.required,
                    constructor = ::ExpiryDateValidator,
                ) { validator -> updatePaymentState { it.copy(expirationDate = validator) } }

            is FormFieldType.CVV ->
                validateAndUpdate(
                    encrypted = paymentState.value.securityCode.value,
                    required = type.required,
                    constructor = ::CvvValidator,
                ) { validator -> updatePaymentState { it.copy(securityCode = validator) } }

            is FormFieldType.NAME ->
                validateAndUpdate(
                    encrypted = paymentState.value.nameOnCard.value,
                    required = type.required,
                    constructor = ::RequiredValidator,
                ) { validator -> updatePaymentState { it.copy(nameOnCard = validator) } }

            is FormFieldType.ADDRESS_LINE_1 ->
                validateAndUpdate(
                    encrypted = paymentState.value.addressLine1.value,
                    required = type.required,
                    constructor = ::RequiredValidator,
                ) { validator -> updatePaymentState { it.copy(addressLine1 = validator) } }

            is FormFieldType.ADDRESS_LINE_2 ->
                validateAndUpdate(
                    encrypted = paymentState.value.addressLine2.value,
                    required = type.required,
                    constructor = ::RequiredValidator,
                ) { validator -> updatePaymentState { it.copy(addressLine2 = validator) } }

            is FormFieldType.CITY ->
                validateAndUpdate(
                    encrypted = paymentState.value.city.value,
                    required = type.required,
                    constructor = ::RequiredValidator,
                ) { validator -> updatePaymentState { it.copy(city = validator) } }

            is FormFieldType.STATE ->
                validateAndUpdate(
                    encrypted = paymentState.value.state.value,
                    required = type.required,
                    constructor = ::RequiredValidator,
                ) { validator -> updatePaymentState { it.copy(state = validator) } }

            is FormFieldType.ZIP ->
                validateAndUpdate(
                    encrypted = paymentState.value.zipCode.value,
                    required = type.required,
                    constructor = ::RequiredValidator,
                ) { validator -> updatePaymentState { it.copy(zipCode = validator) } }

            is FormFieldType.MONTH ->
                validateAndUpdate(
                    encrypted = paymentState.value.month.value,
                    required = type.required,
                    constructor = ::MonthValidator,
                ) { validator -> updatePaymentState { it.copy(month = validator) } }

            is FormFieldType.YEAR ->
                validateAndUpdate(
                    encrypted = paymentState.value.year.value,
                    required = type.required,
                    constructor = ::YearValidator,
                ) { validator -> updatePaymentState { it.copy(year = validator) } }
        }
}
