package com.spreedly.sdk.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PaymentMethodResponse(val transaction: Transaction)

@Serializable
data class Transaction(
    val token: String,
    @SerialName("created_at")
    val createdAt: String,
    @SerialName("updated_at")
    val updatedAt: String,
    val succeeded: Boolean,
    @SerialName("transaction_type")
    val transactionType: String,
    val retained: Boolean,
    val state: String,
    @SerialName("message_key")
    val messageKey: String,
    val message: String,
    @SerialName("payment_method")
    val paymentMethod: PaymentMethodDetails,
)

@Serializable
data class PaymentMethodDetails(
    val token: String,
    @SerialName("created_at")
    val createdAt: String,
    @SerialName("updated_at")
    val updatedAt: String,
    val email: String,
    val data: String? = null,
    @SerialName("storage_state")
    val storageState: String,
    val test: Boolean,
    val metadata: Metadata,
    @SerialName("callback_url")
    val callbackUrl: String? = null,
    @SerialName("last_four_digits")
    val lastFourDigits: String,
    @SerialName("first_six_digits")
    val firstSixDigits: String,
    @SerialName("card_type")
    val cardType: String,
    @SerialName("first_name")
    val firstName: String,
    @SerialName("last_name")
    val lastName: String,
    val month: Int,
    val year: Int,
    val address1: String,
    val address2: String,
    val city: String,
    val state: String,
    val zip: String,
    val country: String,
    @SerialName("phone_number")
    val phoneNumber: String,
    val company: String,
    @SerialName("full_name")
    val fullName: String,
    @SerialName("eligible_for_card_updater")
    val eligibleForCardUpdater: Boolean,
    @SerialName("shipping_address1")
    val shippingAddress1: String,
    @SerialName("shipping_address2")
    val shippingAddress2: String,
    @SerialName("shipping_city")
    val shippingCity: String,
    @SerialName("shipping_state")
    val shippingState: String,
    @SerialName("shipping_zip")
    val shippingZip: String,
    @SerialName("shipping_country")
    val shippingCountry: String,
    @SerialName("shipping_phone_number")
    val shippingPhoneNumber: String,
    @SerialName("issuer_identification_number")
    val issuerIdentificationNumber: String,
    @SerialName("click_to_pay")
    val clickToPay: Boolean,
    val managed: Boolean,
    @SerialName("bin_metadata")
    val binMetadata: BinMetadata,
    @SerialName("subscribed_to_mastercard_abu")
    val subscribedToMastercardAbu: Boolean,
    @SerialName("payment_method_type")
    val paymentMethodType: String,
    val errors: List<String> = emptyList(),
    val fingerprint: String,
    @SerialName("verification_value")
    val verificationValue: String,
    val number: String,
)

@Serializable
data class BinMetadata(val message: String)
