package com.spreedly.sdk.ui

sealed class PaymentResult {
    object Initial : PaymentResult()

    data class Completed(val token: String) : PaymentResult()

    object Canceled : PaymentResult()

    data class Failed(val error: Throwable) : PaymentResult()
}
